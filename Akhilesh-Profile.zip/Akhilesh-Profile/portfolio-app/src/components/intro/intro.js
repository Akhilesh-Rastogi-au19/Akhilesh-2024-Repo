import React from 'react'
import './intro.css'
import { Link } from 'react-scroll';
// import bg from '../../assets/bg.jpg';



const intro = () => {
  return (
     <section id='intro'>
         <div className='introContent'>
             <span className='hello'>Hello</span>
             <span className='introText'>I'm <span className='introName'>Akhilesh Rastogi</span> <br />Website Designer</span> 
             <p>I am Skilled web desinger with experience in creating <br />visual design website</p>  
             <Link><button className='btn'><img src='' alt='' />Hire Me</button></Link>

         </div>
         {/* <img src={bg} alt='Profile' className='bg' /> */}
     </section>
  )
}

export default intro;