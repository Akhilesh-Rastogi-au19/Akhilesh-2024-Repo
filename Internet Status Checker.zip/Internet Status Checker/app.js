

window.addEventListener('load', checkInternetConnection);

function checkInternetConnection() {

    const statusText = document.getElementById('statusText');
    const ipAddressText = document.getElementById('ipAddressText');
    const networkStrenghtText = document.getElementById('networkStrenghtText');

    statusText.textContent = 'Checking....';

    if (navigator.onLine) {
        fetch('https://api.ipify.org?format=json')
            .then((response) => response.json())
            .then((data) => {

                ipAddressText.textContent = data.ip;
                statusText.textContent = 'Connected';

                const connection = navigator.connection;

                const networkStrenght = connection ? connection.downlink + 'Mbps' : 'Unknown';
                networkStrenghtText.textContent = networkStrenght;


            })
            .catch(() => {
                statusText.textContent = 'Disconnected';
                ipAddressText.textContent = '-'
                networkStrenghtText.textContent = '-'
            })



    } else {
        statusText.textContent = 'Disconnected';
        ipAddressText.textContent = '-'
        networkStrenghtText.textContent = '-'
    }


}


